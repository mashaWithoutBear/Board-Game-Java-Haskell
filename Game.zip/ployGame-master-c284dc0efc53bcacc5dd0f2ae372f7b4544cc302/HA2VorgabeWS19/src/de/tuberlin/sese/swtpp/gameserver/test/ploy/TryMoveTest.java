package de.tuberlin.sese.swtpp.gameserver.test.ploy;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import de.tuberlin.sese.swtpp.gameserver.control.GameController;
import de.tuberlin.sese.swtpp.gameserver.model.Player;
import de.tuberlin.sese.swtpp.gameserver.model.User;
import de.tuberlin.sese.swtpp.gameserver.model.ploy.PloyGame;
import de.tuberlin.sese.swtpp.gameserver.model.ploy.Position;//tbd!!!
import de.tuberlin.sese.swtpp.gameserver.model.ploy.PloyMove;//tbd!!!
import de.tuberlin.sese.swtpp.gameserver.model.ploy.Board;//tbd!!!
import de.tuberlin.sese.swtpp.gameserver.model.ploy.Figure;//tbd!!!
import de.tuberlin.sese.swtpp.gameserver.model.ploy.Shield;//tbd!!!
import de.tuberlin.sese.swtpp.gameserver.model.ploy.Lance;//tbd!!!

public class TryMoveTest {

	User user1 = new User("Alice", "alice");
	User user2 = new User("Bob", "bob");
	
	Player whitePlayer = null;
	Player blackPlayer = null;
	PloyGame game = null;
	GameController controller;
	
	@Before
	public void setUp() throws Exception {
		controller = GameController.getInstance();
		controller.clear();
		
		int gameID = controller.startGame(user1, "", "ploy");
		
		game = (PloyGame) controller.getGame(gameID);
		blackPlayer = game.getPlayer(user1);

	}
	
	public void startGame(String initialBoard, boolean whiteNext) {
		controller.joinGame(user2, "ploy");		
		whitePlayer = game.getPlayer(user2);
		
		game.setBoard(initialBoard);
		game.setNextPlayer(whiteNext? whitePlayer:blackPlayer);
	}
	
	public void assertMove(String move, boolean white, boolean expectedResult) {
		if (white)
			assertEquals(expectedResult, game.tryMove(move, whitePlayer));
		else 
			assertEquals(expectedResult,game.tryMove(move, blackPlayer));
	}
	
	public void assertGameState(String expectedBoard, boolean whiteNext, boolean finished, boolean whiteWon) {
		String board = game.getBoard().replaceAll("e", "");
		
		assertEquals(expectedBoard,board);
		assertEquals(finished, game.isFinished());

		if (!game.isFinished()) {
			assertEquals(whiteNext, game.isWhiteNext());
		} else {
			assertEquals(whiteWon, whitePlayer.isWinner());
			assertEquals(!whiteWon, blackPlayer.isWinner());
		}
	}
	

	/*******************************************
	 * !!!!!!!!! To be implemented !!!!!!!!!!!!
	 *******************************************/
	
	@Test
	public void exampleTest() {
		startGame(",w84,w41,w56,w170,w56,w41,w84,/,,w24,w40,w17,w40,w48,,/,,,w16,w16,w16,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,b1,b1,b1,,,/,,b3,b130,b17,b130,b129,,/,b69,b146,b131,b170,b131,b146,b69,",false);
		assertMove("e3-e4-0",false,true);
		assertGameState(",w84,w41,w56,w170,w56,w41,w84,/,,w24,w40,w17,w40,w48,,/,,,w16,w16,w16,,,/,,,,,,,,/,,,,,,,,/,,,,b1,,,,/,,,b1,,b1,,,/,,b3,b130,b17,b130,b129,,/,b69,b146,b131,b170,b131,b146,b69,",true,false,false);
	}
	//TODO: implement test cases of same kind as example here
	@Test
	public void testValidMovesShield() {
		
		//Teste, ob für alle Rotationen das erhoffte Ergebnis
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w2,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		
		//Teste, ob weiß eine weiße Figur schlagen darf
				startGame("w4,w170,,,,,,,/,,,,,,,,/b170,,,,,,,,/,b4,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
				assertMove("a9-b9-1",true,false);
				assertGameState("w4,w170,,,,,,,/,,,,,,,,/b170,,,,,,,,/,b4,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);

				//Teste, ob schwarz eine schwarze Figur schlagen darf
				startGame("b4,b170,,,,,,,/,,,,,,,,/w170,,,,,,,,/,w4,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
				assertMove("a9-b9-1",false,false);
				assertGameState("b4,b170,,,,,,,/,,,,,,,,/w170,,,,,,,,/,w4,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);		
		
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w2,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w4,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		//move.steps<0
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w8,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-g4-1",true,false);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w8,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
		
		
		
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w4,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w8,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w8,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w16,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w16,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w32,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w32,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w64,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w64,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e5-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w128,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
		
		
		//Versuche 2 Felder zu gehen
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e7-1",true,false);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
		
		//Versuche ein Feld in eine erlaubte Richtung zu gehen UND eine erlaubte Drehung zu machen
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-e6-1",true,true);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w2,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
			
		
	}
	

@Test
public void testValidMovesProbe() {//Besteht Test nicht
	
	//Wähle Probe links
	
	//Teste für eine valide Rotation, ob erwünschtes Ergebnis entsteht
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("e5-e5-2",true,true);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w68,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
	
	//Versuche 3 Felder zu gehen
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("e5-e8-0",true,false);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
	
	//Versuche ein Feld in eine erlaubte Richtung zu gehen UND eine erlaubte Drehung zu machen
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("e5-e6-1",true,false);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);


}

@Test
public void testValidMovesLance() {//Besteht Test nicht
	
	//Nimm Lance_rechts
	
	//Teste für eine valide Rotation, ob erwünschtes Ergebnis entsteht
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w69,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("e5-e5-1",true,true);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w138,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
	
	//Versuche 4 Felder zu gehen
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w69,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("e5-e9-0",true,false);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w69,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
	
	//Versuche ein Feld in eine erlaubte Richtung zu gehen UND eine erlaubte Drehung zu machen
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w69,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("e5-e6-1",true,false);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w69,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);


}


@Test
public void testValidMovesCommander() {//Besteht Test nicht
	
	//Teste für eine valide Rotation, ob erwünschtes Ergebnis entsteht
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("a9-a9-1",true,true);
	assertGameState("w85,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);

	//Versuche 2 Felder zu gaehen
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("a9-c7-1",true,false);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
	
	//Versuche ein Feld in eine erlaubte Richtung zu gehen UND eine erlaubte Drehung zu machen
	startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("a9-b8-1",true,false);
	assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w17,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);


}

@Test
public void whiteWins() {//
	
	//Schwarzer Commander wird geschlagen
	startGame("w85,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("a9-b9-0",true,true);
	assertGameState(",w85,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, true, true);

	//Schwarz gibt auf
	startGame("w85,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertGameState("w85,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, true, true);
	
	//Nur noch der schwarze Commander ist übrig
	startGame("b85,,w1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,w85,b34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("d5-e5-0",true,true);
	assertGameState("b85,,w1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w85,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, true, true);


	
}

@Test
public void blackWins() {//Besteht Test nicht
	
	//Weißer Commander wird geschlagen
	startGame("w85,b85,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertMove("b9-a9-0",false,true);
	assertGameState("b85,,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, true, false);

	//Weiß gibt auf
	startGame("w85,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertGameState("w85,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, true, false);
	
	//Nur noch der weiße Commander ist übrig
	startGame("w85,,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,b85,w34,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertMove("d5-e5-0",false,true);
	assertGameState("w85,,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,b85,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, true, false);

	
}

// hendrik
@Test
public void testPlayersTurn() { //Schwarz/Weiß lt. String am Zug => Schwarz/Weiß lt. Implementierung am Zug ?
	
	String board_1 = ",,w17,,w69,,,b170,w68/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,b84,,w170,,";
	
	//Weiß am Zug
	startGame(board_1, true);
	assertGameState(board_1, true, false, false);
	
	// Schwarz am Zug
	startGame(board_1, false);
	assertGameState(board_1, false, false, false);	
	
}

@Test
public void testValidMovesGeneral() {
	
	String board_1 = ",,w17,,w69,,,b170,w68/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,b84,,w170,,";
	
	startGame(board_1, true);
	
	//Teste wilden String
		assertMove("e1-e1-b",true,false);
		assertGameState(board_1, true, false, false);
	
	//Teste für ASCI < a
	assertMove("E9-f9-0",true,false);
	assertGameState(board_1, true, false, false);
	
	assertMove("e9-F9-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste für Start/Ziel < 1
	assertMove("e0-f1-0",true,false);
	assertGameState(board_1, true, false, false);
	
	assertMove("f1-e0-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste für Start/Ziel > 9
	assertMove("c9-c10-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste für Start/Ziel > 9 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!11
		assertMove("c9-cc-0",true,false);
		assertGameState(board_1, true, false, false);
		
	//Teste für Start/Ziel > 9 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!11
		assertMove("cc-c9-0",true,false);
		assertGameState(board_1, true, false, false);
	
	assertMove("c10-c9-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste für mehr als 8 Zeichen
	assertMove("e811-f0-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste mit weniger als 7 Zeichen
	assertMove("e8f10",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste ohne Bindestriche
	assertMove("1234567",true,false);
	assertGameState(board_1, true, false, false);
	
	assertMove("12-3456",true,false);
	assertGameState(board_1, true, false, false);
	
	assertMove("12345-7",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob weiß eine schwarze Figur ziehen darf
	assertMove("h9-i8-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob schwarz eine weiße Figur ziehen darf
	startGame(board_1, false);
	assertMove("e9-b9-0",false,false);
	assertGameState(board_1, false, false, false);
	
	//Teste, ob schwarz eine Figur ziehen darf, wenn weiß am Zug ist.
	startGame(board_1, true);
	assertMove("h9-i8-0",false,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob weiß eine Figur ziehen kann, wo gar keine Figur ist
	startGame(board_1, true);
	assertMove("e3-e4-0",true,false);
	assertGameState(board_1, true, false, false);
	
	assertMove("15-18-1",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob weiß überspringen kann
	assertMove("e9-b9-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Start außerhalb des Spielfeldes gewählt werden kann (Zahl)
	assertMove("e10-e4-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Start außerhalb des Spielfeldes gewählt werden kann (Buchstabe)
	assertMove("k9-e4-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Ziel außerhalb des Spielbretts gewählt werden kann(Zahl)
	assertMove("e9-e10-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Ziel außerhalb des Spielbretts gewählt werden kann(Buchstabe)
	assertMove("i9-k9-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Rotation außerhalb von 0-7 möglich
	assertMove("f9-f9-8",true,false);
	assertGameState(board_1, true, false, false);
	
	assertMove("f9-f9--1",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Sprung in falsche Richtung möglich
	assertMove("f9-f8-0",true,false);
	assertGameState(board_1, true, false, false);
	
	
	//Teste, für Start = Ziel und Drehung = 0
	assertMove("c9-c9-0",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, für Start = Ziel und Drehung verändert nichts am Spielzustand
	assertMove("c9-c9-4",true,false);
	assertGameState(board_1, true, false, false);
	
	//Teste, ob Figur tatsächlich auf Ziel landet
	assertMove("e9-f9-0",true,true);
	assertGameState(",,w17,,,w69,,b170,w68/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,b84,,w170,,", false, false, false);
		
	//Setze wieder board_1
	startGame(board_1, true);
	//Teste, weiß schlägt schwarz => weiße Figur auf Feld von schwarzerFigur & Commander geschlagen => weiß gewinnt
	assertMove("e9-h9-0",true,true);
	assertGameState(",,w17,,,,,w69,w68/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,b84,,w170,,", false, true, true);
	
}

@Test
public void testGameWon() {
	
	//Weiß schlä
}
@Test
public void jumpInEveryDirection() {
	
	//Springe die Diagonalen mit weiß
	
	//links hoch
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("b8-a9-0",true,true);
	assertGameState("w170,,,,,,,,/,,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
	
	//rechts hoch
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("b8-c9-0",true,true);
	assertGameState(",,w170,,,,,,/,,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
	
	//rechts runter
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("b8-c7-0",true,true);
	assertGameState(",,,,,,,,/,,,b85,,,,,/,,w170,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
	
	
	//links runter
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
	assertMove("b8-a7-0",true,true);
	assertGameState(",,,,,,,,/,,,b85,,,,,/w170,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false, false, false);
	
	
	//Springe die Vertikalen und Horizontalen mit schwarz
	
	//Hoch
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertMove("d8-d9-0",false,true);
	assertGameState(",,,b85,,,,,/,w170,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
	
	//Runter
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertMove("d8-d7-0",false,true);
	assertGameState(",,,,,,,,/,w170,,,,,,,/,,,b85,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
	
	//Links
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertMove("d8-c8-0",false,true);
	assertGameState(",,,,,,,,/,w170,b85,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);
	
	//Rechts
	startGame(",,,,,,,,/,w170,,b85,,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", false);
	assertMove("d8-e8-0",false,true);
	assertGameState(",,,,,,,,/,w170,,,b85,,,,/,,,,,,,,/,,,,,,,,/,,,,w1,,,,/,,,,b1,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);

}
@Test
public void testGoInWrongDir() {
//Figur nach links unten gehen darf, obwohl sie nach links zeigt
		startGame("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w64,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true);
		assertMove("e5-d4-0",true,false);
		assertGameState("w170,b170,b1,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,w64,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,", true, false, false);

}
	}
	
