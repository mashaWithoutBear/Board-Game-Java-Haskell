package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;

import de.tuberlin.sese.swtpp.gameserver.model.Move;
import de.tuberlin.sese.swtpp.gameserver.model.Player;

public class PloyMove extends Move  implements Serializable {
private static final long serialVersionUID = 1L;
public Position start;
public Position target;
public int rotation; //a part of the moveString
public int steps;
public int direction; // {0,...,7} in which direction to move from the start to target, 7=North

public PloyMove (String moveString, String boardStatus, Player player) {
		super(moveString, boardStatus, player);
		String[] Split =moveString.split("-");
		this.start= new Position();
		this.target= new Position();
		this.start.col=Split[0].charAt(0);
		this.target.col=Split[1].charAt(0);
		char rowStart=Split[0].charAt(1);
		char rowTarget=Split[1].charAt(1);
		if ((int) rowStart > 48 && (int) rowStart < 58) {
			this.start.row = (Integer.parseInt(String.valueOf(rowStart)));
		} else {
			this.start.row = -1;//if start.row is not int
		}
		if ((int) rowTarget > 48 && (int) rowTarget < 58) {
			this.target.row = (Integer.parseInt(String.valueOf(rowTarget)));
		} else {
			this.target.row = -1;//if target.row is not int
		}
		
		Character rot=Split[2].charAt(0);
		if(Character.isDigit(rot)) {
		this.rotation=Integer.parseInt(Split[2]);}
		else {this.rotation=-1;}
		this.steps=calculateSteps(); //returns -1 if a move is not diagonal, -2 if an unforeseen case occurs 
}
public int calculateSteps() {
	int rowSteps= this.target.row-this.start.row;
	int colSteps= this.target.col - this.start.col;
	if (colSteps==0) {//moving along the same column
		if(rowSteps>0) {this.direction=7;}
		if(rowSteps<0) {this.direction=3;}
		return Math.abs(rowSteps);
	}
	if (rowSteps==0) { //moving along the same row
		if(colSteps>0) {this.direction=5;}
		if(colSteps<0) {this.direction=1;}
		return Math.abs(colSteps);
	}
	//only allowed to run diagonally, not e.g. 2 steps up and 3 steps left
	if(Math.abs(rowSteps)!=Math.abs(colSteps)) {return -1;}
	if(colSteps>0){
		if(rowSteps>0) {this.direction=6;}
		if(rowSteps<0) {this.direction=4;}
		return Math.abs(rowSteps);//=colSteps, doesn't matter, cause running diagonally
	}
	
	else {
		if(rowSteps>0) {this.direction=0;}
		if(rowSteps<0) {this.direction=2;}
		return Math.abs(rowSteps);//=colSteps, doesn't matter, cause running diagonally
	}
}

public boolean isWayFree( Board board) {
	Position pos=this.start.moveOneStep(this.direction);
	while (!pos.equals(this.target)) {
		if(board.whichFigureHere(pos)!=null) {return false;}
		pos=pos.moveOneStep(this.direction);
	}
	return true;
}

}
