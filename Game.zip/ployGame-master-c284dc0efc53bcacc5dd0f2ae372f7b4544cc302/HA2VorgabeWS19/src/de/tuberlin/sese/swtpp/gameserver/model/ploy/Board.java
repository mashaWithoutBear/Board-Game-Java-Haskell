package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class Board implements Serializable{
	private static final long serialVersionUID = 1L;
	public List<Figure> figures=new LinkedList<Figure>();
	public String boardStatus; // String representation. Should it be adjusted after each move???
	//LinkedLists: valid directions of movement / int representations of each figure
	public List<Integer> positionsCommander= new LinkedList<Integer>(); //170 int representations of a Commander to find out whether b84 is a black commander
	public List<Integer> positionsLance = new LinkedList<Integer>();//131; 146; 69;
	public List<Integer> positionsProbe= new LinkedList<Integer>();//17+7; 130+7;129+7
	public List<Integer> positionsShield= new LinkedList<Integer>();//1 and 7 other rotations
	int [] c= {170}, l= {131, 146, 69}, p= {17,130,129}, s= {1};

	public Board() {
		// standard start of the game:
		this.boardStatus = ",w84,w41,w56,w170,w56,w41,w84,/,,w24,w40,w17,w40,w48,,/,,,w16,w16,w16,,,/,,,,,,,,/,,,,,,,,/,,,,,,,,/,,,b1,b1,b1,,,/,,b3,b130,b17,b130,b129,,/,b69,b146,b131,b170,b131,b146,b69,";
		fillLists(positionsCommander, c);
		fillLists(positionsLance, l);
		fillLists(positionsProbe, p);
		fillLists(positionsShield, s);
		stringToObject(boardStatus);
	}
	
	public Board(String boardStatus) {// für setBoard zum Testen
		this.boardStatus=boardStatus;
		fillLists(positionsCommander, c);
		fillLists(positionsLance, l);
		fillLists(positionsProbe, p);
		fillLists(positionsShield, s);
		stringToObject(boardStatus);
	}
	
	public void fillLists(List<Integer> list, int[] c) {
		for (int j = 0; j < c.length; j++) {
			list.add(c[j]);
			for (int i = 1; i < 8; i++) {
				int a = Figure.rotateFigure(c[j], i);
				if (!list.contains(a)) {
				list.add(a);}
			}
		}
	}
	
	
	public Figure createFigureSubclass(String figureToBe, Position pos, Boolean isWhite) {//w64
		int i= Integer.parseInt(figureToBe.substring(1));
		for(int j : this.positionsCommander) {
			if (i==j) {return new Commander(pos, isWhite, figureToBe);}
		}
		for(int j : this.positionsShield) {
			if (i==j) {return new Shield (pos, isWhite, figureToBe);}
		}
		for(int j : this.positionsLance) {
			if (i==j) {return new Lance (pos, isWhite, figureToBe);}
		}
		return new Probe (pos, isWhite, figureToBe);
	}
	
	public Figure createFigure(String figureToBe, Position pos) {
		Boolean isWhite = Figure.isFigureWhite(figureToBe);
		Figure f = null;
		f = createFigureSubclass(figureToBe, pos, isWhite);
		return f;
	}

	/* für Kommunikation mit dem WebServer; 
	vielleicht auch für die Darstellung der Änderungen während des Spiels 
	(z.b. Figure wird gelöscht->String muss sich Ändern)*/
	
	public String objectToString () { 
		String status="";
		for (int j=9; j>=1;j--) {
			for (char ch='a'; ch<='i'; ch++) {
				Position pos= new Position(ch,j);
				Figure f= whichFigureHere(pos);
				if(f!=null) {
					status=status.concat(f.w84);
					status=status.concat(",");
				}
				else status=status.concat(",");
			}
			status= status.substring(0,(status.length()-1));
			status=status.concat("/");
		}
		status= status.substring(0,(status.length()-1));
		this.boardStatus=status;
		return status;}
	
	public void stringToObject(String status) {
		String[] Split = status.split("/"); // separation per rows (int)
		for (int i = 0; i < Split.length; i++) {
			String[] Split2 = Split[i].split(",");// separation per columns (char)
			for (int j = 0; j < Split2.length; j++) {
				if (!Split2[j].isEmpty()) {
					Position pos= new Position((char)((int)'a'+j),9-i);//TODO: implement instead of dummy
					String figureToBe = Split2[j];
					Figure f=createFigure(figureToBe, pos);//creates a Figure out of "w64"
					if (f==null) {}//what to do on error???
					this.figures.add(f);
				}
			}
		}
	}

	
	
	public Figure whichFigureHere(Position position) {
		Figure figure = null;
		for (Figure f : this.figures) {
			if (f.position.equals(position)) {
				figure = f;
				return figure;
			}
		}
		return figure;
	}
	
	public void deleteFigure(Figure toDelete) {
		this.figures.remove(toDelete);
	}
	
	
}
