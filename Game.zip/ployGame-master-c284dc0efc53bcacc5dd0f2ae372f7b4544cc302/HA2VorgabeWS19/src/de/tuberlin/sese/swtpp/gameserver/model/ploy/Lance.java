package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;

public class Lance extends Figure implements Serializable{
	private static final long serialVersionUID = 1L;

	public Lance(Position position, boolean white, String w84) {
		super(position, white, w84);
		this.maxSteps=3;
	}

}
