package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;

public class Probe extends Figure implements Serializable{
private static final long serialVersionUID = 1L;

	public Probe(Position position, boolean white, String w84) {
		super(position, white, w84);
		this.maxSteps=2;
		
	}
}
