package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;

public abstract class Figure implements Serializable{
private static final long serialVersionUID = 1L;
public boolean white; //white= true, black=false
public Position position;
public int maxSteps;
public String w84; 

// Darstellung für steps und/oder rotation notwendig

protected Figure(Position position, boolean white, String w84) {
		this.position= position;
		this.white= white;
		this.w84= w84;}

	public static int rotateFigure(int x, int rotation) {
		int fH = ((x << rotation) & 0xFF);
		int sH = (x >>> (8 - rotation));
		int y = (fH | sH);
		return y;
	}

	public static Boolean checkMove(Figure myFigure, PloyMove move) {
		//is the token itself allowed to move this amount of steps? 
		String subclass = myFigure.getClass().getSimpleName();
		if (myFigure.maxSteps < move.steps) {
			return false;
		}
		//in this direction? steps>0!
		if (move.steps>0) {int i=myFigure.getInt();
		String binary= String.format("%08d", Integer.parseInt(Integer.toBinaryString(i)));
		Character c=binary.charAt(move.direction);
		if (c.equals('0')) {return false;}}
		//is the token itself allowed to move and rotate?
		if (move.steps != 0 && move.rotation != 0) {
			if (!subclass.equals("Shield")) {
				return false;
			}
		}
		return true;
	}


public static Boolean isFigureWhite (String figureToBe) {
if (figureToBe.charAt(0)=='w') {return true;}
else {return false;} 
}
public void changePosition(Position newPosition) {
	this.position=newPosition;
}

public void changeW84(String w84, int rotation) {
	//save w
	String sub = w84.substring(0,1);
	//calculate + set new w84
	int temp=getInt();
	int y=rotateFigure(temp,rotation);
	this.w84=sub + Integer.toString(y);
}

public int getInt() {
		String sub = w84.substring(1);
		int temp=Integer.parseInt(sub);
		return temp;
}
	
}
