package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;

public class Position implements Serializable {
	private static final long serialVersionUID = 1L;
	public char col;
	public int row;

	public Position () {
		}
public Position (char col,int row) {
	this.row=row;
	this.col=col;
	}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Position other = (Position) obj;
	if (col != other.col)
		return false;
	if (row != other.row)
		return false;
	return true;
}
//necessary e.g. for tryMove
public Position moveOneStep( int direction) {
	Position newPosition=null;
	switch(direction){
    case 7:
    	newPosition= new Position(this.col,this.row+1); break;
    case 6:
    	newPosition= new Position((char) ((int)this.col+1),this.row+1); break;
    case 5:
    	newPosition= new Position((char) ((int)this.col+1),this.row); break;
    case 4:
    	newPosition= new Position( (char) ((int)this.col+1),this.row-1); break;
    case 3:
    	newPosition= new Position(this.col,this.row-1); break;
    case 2:
    	newPosition= new Position((char) ((int)this.col-1), this.row-1); break;
    case 1:
    	newPosition= new Position((char) ((int)this.col-1),this.row); break;
    default:
    	newPosition= new Position((char) ((int)this.col-1), this.row+1); break;
		}
	return newPosition;
	}
}
