package de.tuberlin.sese.swtpp.gameserver.model.ploy;

import java.io.Serializable;

import de.tuberlin.sese.swtpp.gameserver.model.Game;
import de.tuberlin.sese.swtpp.gameserver.model.Player;

/**
 * Class Cannon extends the abstract class Game as a concrete game instance that
 * allows to play Cannon.
 *
 */
public class PloyGame extends Game implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5424778147226994452L;

	/************************
	 * member
	 ***********************/

	// just for better comprehensibility of the code: assign white and black player
	private Player blackPlayer;
	private Player whitePlayer;

	// internal representation of the game state
	// TODO: insert additional game data here, such as Board, ???
	public Board board; // added

	/************************
	 * constructors
	 ***********************/

	public PloyGame() {
		super();
		// TODO: init internal representation
		this.board = new Board();// added
		//start game!
	}

	public String getType() {
		return "ploy";
	}

	/*******************************************
	 * Game class functions already implemented
	 ******************************************/

	@Override
	public boolean addPlayer(Player player) {
		if (!started) {
			players.add(player);

			// game starts with two players
			if (players.size() == 2) {
				started = true;
				this.blackPlayer = players.get(0);
				this.whitePlayer = players.get(1);
				nextPlayer = blackPlayer;
			}
			return true;
		}

		return false;
	}

	@Override
	public String getStatus() {
		if (error)
			return "Error";
		if (!started)
			return "Wait";
		if (!finished)
			return "Started";
		if (surrendered)
			return "Surrendered";
		if (draw)
			return "Draw";

		return "Finished";
	}

	@Override
	public String gameInfo() {
		String gameInfo = "";

		if (started) {
			if (blackGaveUp())
				gameInfo = "black gave up";
			else if (whiteGaveUp())
				gameInfo = "white gave up";
			else if (didWhiteDraw() && !didBlackDraw())
				gameInfo = "white called draw";
			else if (!didWhiteDraw() && didBlackDraw())
				gameInfo = "black called draw";
			else if (draw)
				gameInfo = "draw game";
			else if (finished)
				gameInfo = blackPlayer.isWinner() ? "black won" : "white won";
		}

		return gameInfo;
	}

	@Override
	public String nextPlayerString() {
		return isWhiteNext() ? "w" : "b";
	}

	@Override
	public int getMinPlayers() {
		return 2;
	}

	@Override
	public int getMaxPlayers() {
		return 2;
	}

	@Override
	public boolean callDraw(Player player) {

		// save to status: player wants to call draw
		if (this.started && !this.finished) {
			player.requestDraw();
		} else {
			return false;
		}

		// if both agreed on draw:
		// game is over
		if (players.stream().allMatch(p -> p.requestedDraw())) {
			this.draw = true;
			finish();
		}
		return true;
	}

	@Override
	public boolean giveUp(Player player) {
		if (started && !finished) {
			if (this.whitePlayer == player) {
				whitePlayer.surrender();
				blackPlayer.setWinner();
			}
			if (this.blackPlayer == player) {
				blackPlayer.surrender();
				whitePlayer.setWinner();
			}
			surrendered = true;
			finish();

			return true;
		}

		return false;
	}

	/*******************************************
	 * Helpful stuff
	 ******************************************/

	/**
	 * 
	 * @return True if it's white player's turn
	 */
	public boolean isWhiteNext() {
		return nextPlayer == whitePlayer;
	}

	/**
	 * Ends game after regular move (save winner, finish up game state,
	 * histories...)
	 * 
	 * @param player
	 * @return
	 */
	public boolean regularGameEnd(Player winner) {
		// public for tests
		if (finish()) {
			winner.setWinner();
			return true;
		}
		return false;
	}

	public boolean didWhiteDraw() {
		return whitePlayer.requestedDraw();
	}

	public boolean didBlackDraw() {
		return blackPlayer.requestedDraw();
	}

	public boolean whiteGaveUp() {
		return whitePlayer.surrendered();
	}

	public boolean blackGaveUp() {
		return blackPlayer.surrendered();
	}

	/*******************************************
	 * !!!!!!!!! To be implemented !!!!!!!!!!!!
	 ******************************************/

	@Override
	public void setBoard(String state) { //creates a new board. Have I understood correctly?
		this.board= new Board(state);
	}

	@Override
	public String getBoard() {
		String status = this.board.objectToString();
		return status;
	}

	// checks the string and creates an object Move from a string
	public PloyMove moveFromString(String moveString, Player player) {
		//check the length and "-" in order to separate the string in 3 parts
		String boardStatus=this.board.objectToString();
		if (moveString.length() != 7) {return null;} 
		char c = '-';
		if (moveString.charAt(2) != c || moveString.charAt(5) != c) {return null;}
		
		//if successful, create a new Move object
		PloyMove move = new PloyMove(moveString, boardStatus, player);
		
		if (move.rotation >7) {return null;}
		
		//a move must change the position and/or perform a rotation
		if (move.steps==0 && move.rotation == 0) {return null;} 

		//checkPosition (format d2? within the field?)
		if (move.start.col < 'a' || move.start.col > 'i') {return null;}
		if (move.target.col < 'a' || move.target.col > 'i') {return null;}
		
		if (move.start.row < 1) {return null;}
		if (move.target.row < 1) {return null;}

		return move;
	}
	
	public Boolean checkMove(Player player,Figure myFigure,Figure herFigure,PloyMove move){ //Game-specific check; Figure-specific check see Figure.checkMove()
		if (!isPlayersTurn(player)) {return false;} // it's player's turn?
		if (myFigure==null) {return false;} //nothing stands on the start
		
		// is myFigure really mine? (the right color of the token)
		if ((player == blackPlayer && myFigure.white) || (player == whitePlayer && !myFigure.white)) {
			return false;	
		}
		//are there steps?
		if (move.steps>0) {
			// is there a token on the way from start to target?->not allowed
			if (!move.isWayFree(this.board)) {return false;}
		// is anything standing on the target? If own color->not allowed. 
		//If other color it's okay->the figure will be deleted in doMove
			if (herFigure!=null) {
				if ((player == blackPlayer && !herFigure.white) || (player == whitePlayer && herFigure.white)) {
					return false;
				}
			}
		}
		
		return true;
		}
		
		
	public boolean doMove(String moveString, PloyMove move, Player player ,Figure herFigure, Figure myFigure) {
		String boardBefore = getBoard();
		//a figure of the other color is standing on the target -> delete from board
		if (herFigure!=null && !(herFigure.position.equals(myFigure.position))) {
			this.board.deleteFigure(herFigure);
		}
		myFigure.changePosition(move.target);
		//rotate figure
		if (move.rotation!=0) {
			myFigure.changeW84(myFigure.w84, move.rotation);
		}
		String boardAfter= getBoard();
		if(boardBefore.equals(boardAfter)) {return false;}
		
		//change player
		if (player==blackPlayer) {
		setNextPlayer(whitePlayer);}
		else{setNextPlayer(blackPlayer);}
		//if  game is won: in Class Game: change status to won
		if(gameWon()) {
			this.finished=true;
			player.setWinner();
		}
		PloyMove update = new PloyMove(moveString, boardBefore, player);
		this.history.add(update);
		//set winner
		
		return true;
	}

	@Override
	public boolean tryMove(String moveString, Player player) { // <start>-<ziel>-<drehung>
		PloyMove move = moveFromString(moveString,player);
		if (move == null||move.steps<0) {return false;} //constructor returns step=-1 if no figure is allowed to perform this move
		if (move.rotation<0){return false;}
		//anything stands on the "start" and "target" position?
		Figure myFigure=this.board.whichFigureHere(move.start);
		Figure herFigure=this.board.whichFigureHere(move.target);
		
		if(!checkMove(player,myFigure,herFigure, move)|| !Figure.checkMove(myFigure,move)) {return false;}
		
		//if move valid do move and return true
		Boolean moveDone=doMove(moveString, move, player, herFigure, myFigure);
		if (!moveDone) {return false;}
		return true;
	}
	public boolean gameWon() {
		//einer der beiden Spieler hat keinen Commander mehr oder nur noch den Commander
		int countCommander = 0;
		int countWhite =0;
		int countBlack =0;
		for (Figure f: this.board.figures) {
			String subclass = f.getClass().getSimpleName();
			if(subclass.equals("Commander")) {countCommander++;}
			if(f.white) {countWhite++;}
			if(!f.white){countBlack++;}
		}
		if(countCommander<2 || countWhite<2 ||countBlack<2) {return true;}
		return false;
		}


}
